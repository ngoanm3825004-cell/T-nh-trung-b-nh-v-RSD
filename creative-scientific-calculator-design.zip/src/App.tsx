import { useState, useMemo } from "react"
import { cn } from "./utils/cn"

export default function App() {
  const [values, setValues] = useState<string[]>(["", "", ""])
  const [unit, setUnit] = useState("mg/L")

  const nums = useMemo(() => values.map(v => {
    const n = parseFloat(v.replace(",", "."))
    return isNaN(n) ? null : n
  }), [values])

  const filled = nums.filter(n => n !== null) as number[]
  const allFilled = filled.length === 3

  const { mean, sd, rsd } = useMemo(() => {
    if (!allFilled) return { mean: null, sd: null, rsd: null }
    const m = filled.reduce((a, b) => a + b, 0) / 3
    // Sample standard deviation (n-1)
    const variance = filled.reduce((s, v) => s + (v - m) ** 2, 0) / (filled.length - 1)
    const s = Math.sqrt(variance)
    const r = m !== 0 ? (s / m) * 100 : null
    return { mean: m, sd: s, rsd: r }
  }, [filled, allFilled])

  const update = (i: number, val: string) => {
    const next = [...values]
    // Allow numbers, minus, decimal comma/dot
    if (/^-?[0-9]*[.,]?\d*$/.test(val) || val === "") {
      next[i] = val
      setValues(next)
    }
  }

  const reset = () => setValues(["", "", ""])

  const fmt = (n: number | null, d = 4) =>
    n === null ? "—" : new Intl.NumberFormat("vi-VN", { maximumFractionDigits: d, minimumFractionDigits: 2 }).format(n)

  return (
    <div className="min-h-screen bg-[#06080f] text-zinc-100 selection:bg-fuchsia-500/30 selection:text-fuchsia-200">
      {/* Grid background */}
      <div className="fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(56,189,248,0.08),transparent_60%)]" />
        <div className="absolute inset-0 opacity-[0.15]"
          style={{
            backgroundImage:
              "linear-gradient(transparent 95%, rgba(148,163,184,0.5) 95%), linear-gradient(90deg, transparent 95%, rgba(148,163,184,0.5) 95%)",
            backgroundSize: "32px 32px",
          }}
        />
        {/* Scanning line */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-1/2 left-0 right-0 h-[200%] opacity-40 [mask-image:linear-gradient(to_bottom,transparent,white,transparent)]">
            <div className="h-[3px] w-full bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-[scan_6s_linear_infinite]" />
          </div>
        </div>
      </div>

      <main className="relative mx-auto max-w-6xl px-4 py-10 lg:py-14">
        {/* Header */}
        <header className="mb-10 flex flex-col items-center gap-4 text-center">
          <div className="inline-flex items-center gap-3 rounded-full border border-cyan-400/20 bg-cyan-400/5 px-4 py-2 backdrop-blur">
            <span className="relative flex size-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-75" />
              <span className="relative inline-flex size-2 rounded-full bg-cyan-400" />
            </span>
            <span className="font-mono text-[11px] tracking-[0.22em] text-cyan-200">PHÒNG THÍ NGHIỆM SỐ • V1.0</span>
          </div>

          <h1 className="font-mono text-3xl md:text-[40px] font-semibold tracking-tight">
            <span className="bg-gradient-to-b from-zinc-100 to-zinc-400 bg-clip-text text-transparent">MÁY PHÂN TÍCH TRUNG BÌNH & %RSD</span>
          </h1>
          <p className="max-w-2xl text-balance text-[15px] leading-relaxed text-zinc-400">
            Nhập ba giá trị đo lặp. Hệ thống tính giá trị trung bình, độ lệch chuẩn mẫu và <em className="not-italic text-zinc-200">%RSD (Relative Standard Deviation)</em> – chỉ số đánh giá độ lặp lại trong kiểm nghiệm.
          </p>
        </header>

        <section className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          {/* Left: Inputs as test tubes */}
          <div className="relative rounded-[28px] border border-white/10 bg-white/[0.02] p-6 md:p-8 backdrop-blur-xl shadow-[inset_0_1px_0_rgba(255,255,255,0.06),0_20px_80px_-20px_rgba(14,165,233,0.35)]">
            {/* Top bar */}
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="grid size-9 place-items-center rounded-xl bg-zinc-900 ring-1 ring-white/10">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-cyan-300">
                    <path d="M7 3h10M9 3v4.5a3.5 3.5 0 01-7 0V3m7 0v6a3 3 0 006 0V3" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                </div>
                <div>
                  <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-500">Mẫu đo</div>
                  <div className="text-sm text-zinc-200">Ba phép đo lặp (n = 3)</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <label className="font-mono text-[11px] uppercase tracking-widest text-zinc-500">Đơn vị</label>
                <select
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  className="rounded-xl border border-white/10 bg-zinc-900/70 px-3 py-2 text-sm text-zinc-200 outline-none focus:ring-2 focus:ring-cyan-400/30"
                >
                  <option>mg/L</option>
                  <option>µg/mL</option>
                  <option>ppm</option>
                  <option>%</option>
                  <option>không đơn vị</option>
                </select>
              </div>
            </div>

            {/* Tubes */}
            <div className="grid gap-6 sm:grid-cols-3">
              {values.map((v, i) => {
                const n = nums[i]
                const h = n !== null ? Math.min(100, Math.max(8, ((Math.abs(n)) % 97) + 8)) : 8
                return (
                  <div key={i} className="group relative">
                    <div className="mx-auto w-[88%]">
                      {/* Tube cap */}
                      <div className="mx-auto h-3 w-10 rounded-t-full bg-gradient-to-b from-zinc-300 to-zinc-500 shadow-[0_0_0_1px_rgba(255,255,255,0.15)_inset]" />
                      {/* Tube body */}
                      <div className="relative mx-auto h-[240px] rounded-[28px] border border-white/10 bg-gradient-to-b from-zinc-900/60 to-zinc-950/80 p-[10px] shadow-[inset_0_0_40px_rgba(56,189,248,0.08)]">
                        {/* Liquid */}
                        <div className="absolute inset-[10px] overflow-hidden rounded-[22px]">
                          <div
                            className={cn(
                              "absolute inset-x-0 bottom-0 rounded-[22px] transition-[height] duration-700 ease-[cubic-bezier(.22,1,.36,1)]",
                              "bg-[radial-gradient(120%_120%_at_50%_0%,rgba(56,189,248,0.9),rgba(14,165,233,0.65)_45%,rgba(14,165,233,0.35))]",
                              "shadow-[inset_0_12px_30px_rgba(255,255,255,0.35),inset_0_-20px_40px_rgba(2,132,199,0.45)]",
                              n === null && "opacity-60"
                            )}
                            style={{ height: `${h}%` }}
                          >
                            {/* Meniscus */}
                            <div className="absolute -top-3 left-1/2 h-6 w-[86%] -translate-x-1/2 rounded-[999px] bg-gradient-to-b from-white/70 to-white/0 blur-[2px]" />
                            {/* Light sweep */}
                            <div className="pointer-events-none absolute inset-0 opacity-70 mix-blend-screen">
                              <div className="absolute inset-0 animate-[sweep_3.5s_ease-in-out_infinite] bg-[linear-gradient(115deg,transparent_20%,rgba(255,255,255,0.6)_40%,transparent_60%)]" />
                            </div>
                          </div>
                          {/* Scale marks */}
                          <div className="pointer-events-none absolute inset-0 grid grid-rows-10">
                            {Array.from({ length: 10 }).map((_, m) => (
                              <div key={m} className="border-t border-white/5 first:border-t-0" />
                            ))}
                          </div>
                        </div>

                        {/* Glass highlight */}
                        <div className="pointer-events-none absolute inset-[10px] rounded-[22px] ring-1 ring-white/10 [mask-image:linear-gradient(transparent,white_20%,white_80%,transparent)]" />
                        <div className="pointer-events-none absolute left-[18px] top-1/3 h-[40%] w-[6px] rounded-full bg-gradient-to-b from-white/40 via-white/10 to-transparent blur-[0.5px]" />
                      </div>

                      {/* Input */}
                      <div className="mt-4 space-y-2">
                        <label className="flex items-center justify-between">
                          <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-zinc-400">MẪU 0{i + 1}</span>
                          <span className="font-mono text-[10px] text-zinc-500">ID: {("T-" + (i + 1)).padEnd(4, "0")}</span>
                        </label>
                        <div className="relative">
                          <input
                            inputMode="decimal"
                            value={v}
                            onChange={(e) => update(i, e.target.value)}
                            placeholder="0.0000"
                            className="w-full rounded-2xl border border-white/10 bg-zinc-950/70 px-4 py-3 pr-16 font-mono text-[17px] tabular-nums text-zinc-100 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)] outline-none placeholder:text-zinc-600 focus:border-cyan-400/40 focus:ring-2 focus:ring-cyan-400/20"
                          />
                          <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded-lg bg-zinc-900 px-2 py-1 font-mono text-[11px] text-zinc-400 ring-1 ring-white/10">{unit}</span>
                        </div>
                        <p className="h-5 font-mono text-[11px] text-zinc-500">
                          {n === null && v !== "" ? "Định dạng chưa hợp lệ" : n !== null ? `≈ ${fmt(n)} ${unit}` : "Chờ nhập dữ liệu…"}
                        </p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Actions */}
            <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-white/5 pt-6">
              <div className="font-mono text-[11px] tracking-widest text-zinc-500">NHẬP XONG • NHẤN TAB ĐỂ CHUYỂN Ô</div>
              <div className="flex items-center gap-2">
                <button
                  onClick={reset}
                  className="rounded-xl border border-white/10 bg-zinc-900 px-4 py-2 text-sm text-zinc-200 hover:bg-zinc-800 active:scale-[0.98]"
                >
                  Làm mới
                </button>
                <button
                  onClick={() => navigator.clipboard.writeText(
                    allFilled ? `Mean=${fmt(mean)} ${unit}, SD=${fmt(sd)}, %RSD=${fmt(rsd)}%` : ""
                  )}
                  disabled={!allFilled}
                  className={cn(
                    "rounded-xl px-4 py-2 text-sm font-medium",
                    allFilled
                      ? "bg-cyan-500 text-black hover:bg-cyan-400 active:scale-[0.98]"
                      : "cursor-not-allowed border border-white/10 bg-zinc-900 text-zinc-500"
                  )}
                >
                  Sao chép kết quả
                </button>
              </div>
            </div>
          </div>

          {/* Right: Analysis display */}
          <aside className="relative">
            <div className="sticky top-6 space-y-6">
              {/* Instrument display */}
              <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#0a0e18]/80 p-6 backdrop-blur-xl shadow-[inset_0_1px_0_rgba(255,255,255,0.06),0_20px_80px_-20px_rgba(56,189,248,0.35)]">
                {/* Screen bezel */}
                <div className="pointer-events-none absolute inset-0 rounded-[28px] ring-1 ring-white/10 [mask-image:radial-gradient(120%_140%_at_50%_-10%,black,transparent_70%)]" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="inline-block size-[8px] animate-pulse rounded-full bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)]" />
                    <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-emerald-300">ANALYZER • ONLINE</span>
                  </div>
                  <div className="font-mono text-[10px] text-zinc-500">MODE: SAMPLE • N=3</div>
                </div>

                {/* CRT screen */}
                <div className="mt-4 rounded-[22px] bg-[#071018] p-4 ring-1 ring-white/10">
                  <div className="relative overflow-hidden rounded-[16px] bg-[radial-gradient(120%_140%_at_50%_0%,rgba(20,184,166,0.08),transparent_60%)] p-5">
                    {/* Scanlines */}
                    <div className="pointer-events-none absolute inset-0 opacity-40 mix-blend-screen" style={{
                      backgroundImage: "repeating-linear-gradient(transparent, transparent 2px, rgba(255,255,255,0.04) 3px)"
                    }} />
                    {/* Glare */}
                    <div className="pointer-events-none absolute -inset-6 bg-[radial-gradient(60%_60%_at_50%_0%,rgba(56,189,248,0.18),transparent_70%)]" />

                    <div className="relative grid gap-5">
                      <div>
                        <div className="font-mono text-[11px] uppercase tracking-[0.22em] text-zinc-500">KẾT QUẢ TÍNH TOÁN</div>
                        <div className="mt-2 grid grid-cols-3 gap-3">
                          {[
                            { k: "Mean", v: mean, unit },
                            { k: "SD", v: sd, unit },
                            { k: "%RSD", v: rsd, unit: "%" },
                          ].map((it) => (
                            <div key={it.k} className="rounded-2xl border border-white/5 bg-zinc-950/60 p-3">
                              <div className="font-mono text-[10px] uppercase tracking-widest text-zinc-500">{it.k}</div>
                              <div className="mt-1 font-mono text-[22px] leading-none tracking-tight text-cyan-200">
                                {fmt(it.v)}
                                <span className="ml-1 align-super font-sans text-[11px] text-zinc-400">{it.unit}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Mini chart */}
                      <div className="rounded-2xl border border-white/5 bg-zinc-950/60 p-3">
                        <div className="mb-2 flex items-center justify-between">
                          <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-zinc-500">Phân bố mẫu</span>
                          <span className="font-mono text-[10px] text-zinc-500">AUTO SCALE</span>
                        </div>
                        <div className="relative h-[86px] overflow-hidden rounded-xl bg-[#0b1220] ring-1 ring-white/5">
                          {/* Axes */}
                          <div className="absolute inset-0 grid grid-cols-3">
                            {nums.map((n, i) => {
                              const max = Math.max(...filled, 1)
                              const h = n !== null ? Math.max(6, Math.min(100, (Math.abs(n) / max) * 100)) : 0
                              return (
                                <div key={i} className="relative">
                                  <div className="absolute inset-0 origin-bottom">
                                    {/* Bar */}
                                    <div
                                      className="absolute bottom-2 left-1/2 h-[72%] w-[62%] -translate-x-1/2 overflow-hidden rounded-[14px] border border-cyan-400/20 bg-cyan-500/10"
                                    >
                                      <div
                                        className="absolute inset-x-0 bottom-0 rounded-[12px] bg-gradient-to-t from-cyan-400 via-cyan-300 to-white shadow-[inset_0_10px_20px_rgba(255,255,255,0.35)]"
                                        style={{ height: `${h}%` }}
                                      />
                                      {/* Shine */}
                                      <div className="pointer-events-none absolute inset-0 opacity-70 mix-blend-screen">
                                        <div className="absolute inset-0 animate-[sweep_3.5s_ease-in-out_infinite] bg-[linear-gradient(115deg,transparent_20%,rgba(255,255,255,0.55)_40%,transparent_60%)]" />
                                      </div>
                                    </div>
                                    {/* Label */}
                                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 font-mono text-[10px] text-zinc-400">M0{i+1}</div>
                                  </div>
                                </div>
                              )
                            })}
                          </div>
                          {/* Grid */}
                          <div className="pointer-events-none absolute inset-0 opacity-30" style={{
                            backgroundImage:
                              "linear-gradient(transparent 95%, rgba(148,163,184,0.3) 95%), linear-gradient(90deg, transparent 95%, rgba(148,163,184,0.3) 95%)",
                            backgroundSize: "18px 18px",
                          }} />
                        </div>
                      </div>

                      {/* Formula */}
                      <div className="rounded-2xl border border-white/5 bg-zinc-950/60 p-3">
                        <div className="font-mono text-[11px] uppercase tracking-[0.22em] text-zinc-500">Công thức</div>
                        <div className="mt-2 grid gap-2 text-[13px] leading-relaxed text-zinc-300">
                          <div className="font-mono text-[12px] text-zinc-200">
                            <span className="text-zinc-500">Mean</span> = (x₁ + x₂ + x₃) / 3
                          </div>
                          <div className="font-mono text-[12px] text-zinc-200">
                            <span className="text-zinc-500">SD</span> = √[ Σ(xᵢ − Mean)² / (n − 1) ]
                          </div>
                          <div className="font-mono text-[12px] text-zinc-200">
                            <span className="text-zinc-500">%RSD</span> = (SD / Mean) × 100%
                          </div>
                          <p className="mt-1 text-[12px] text-zinc-400">
                            %RSD thấp → độ lặp lại tốt. Ngưỡng chấp nhận thường &lt; 2% (HPLC), &lt; 5% (sinh học), tùy phương pháp.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer ribbon */}
                <div className="mt-4 flex items-center justify-between rounded-2xl border border-white/5 bg-zinc-950/70 px-3 py-2 font-mono text-[11px] text-zinc-500">
                  <span>LOT: ANALYT-2026-03 • OP: USER</span>
                  <span className="tracking-widest">UTC {new Date().toISOString().slice(0, 10)}</span>
                </div>
              </div>

              {/* Note card */}
              <div className="rounded-[22px] border border-amber-400/15 bg-amber-400/[0.06] p-4 text-[13px] leading-relaxed text-amber-100/90">
                <div className="mb-1 font-mono text-[11px] uppercase tracking-[0.22em] text-amber-200/80">Lưu ý phòng thí nghiệm</div>
                Đảm bảo 3 phép đo trong cùng điều kiện: thiết bị, lô thuốc thử, nhiệt độ. %RSD chỉ có ý nghĩa khi Mean ≠ 0 và dữ liệu không ngoại lai.
              </div>
            </div>
          </aside>
        </section>

        {/* Bottom note */}
        <footer className="mx-auto mt-12 max-w-3xl text-center text-[12px] leading-relaxed text-zinc-500">
          Được thiết kế cho tính toán nhanh trong phòng lab. Kết quả hiển thị theo độ lệch chuẩn mẫu (n−1).
        </footer>
      </main>

      {/* Animations */}
      <style>{`
        @keyframes scan {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        @keyframes sweep {
          0% { transform: translateX(-120%); }
          50% { transform: translateX(120%); }
          100% { transform: translateX(120%); }
        }
      `}</style>
    </div>
  )
}